package com.example.kpuhuddle;

import android.view.View;

public interface ItemClickListener {

    void onItemClickListener(View v, int position);
}